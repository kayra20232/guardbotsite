=== Theme: Parallax eleven ===
Contributors: ThemeHunk
Tags: one-column, two-columns, grid-layout, right-sidebar, custom-colors, custom-menu, theme-options, sticky-post, translation-ready, footer-widgets, blog 
Requires at least: 4.5
Tested up to: 5.5.1
Requires PHP: 5.6
Stable tag: 1.0.2
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"Parallax eleven a onepage WordPress Theme" By ThemeHunk.

== Description ==
  Parallax Eleven is a child theme of featuredlite loaded with total customization options plus unique gradient touch.
  
== Resources ==

WordPress theme "parallax eleven " is a child theme of "featuredlite".
featuredlite Theme is licensed under the GPL3.

License for Image:
1. Screenshot
Resource link: https://pixabay.com/en/manhattan-empire-state-building-336708/
Licensed under the CCO license.
License link : https://pixabay.com/en/service/terms/#usage

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Changelog ==
== 1.0.2  =
* Style Issue Fixed.
== 1.0.1 ==
* compatible with latest wordpress.
== 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.1  =
* compatible with latest wordpress.

Once again, thank you so much for trying the parallax eleven WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.